import type { AuthContext } from '../modules/auth/types.js';
declare global {
  namespace Express {
    interface Request { requestId: string; auth?: AuthContext }
  }
}
export {};
