import type { SqlExecutor } from '../../db/database.js';

type SafeValue = string | number | boolean | null;
export interface ActivityEntry {
  actorId: string | null; action: string; entityType: string; entityId?: string;
  before?: Record<string, SafeValue>; after?: Record<string, SafeValue>;
  reason?: string; requestId?: string;
}

// Explicit safe fields, not full request/user/session objects. Do not log secrets.
const safeKeys = new Set(['id','name','username','role','isActive','mustChangePassword','revokedSessions']);
export async function writeActivity(tx: SqlExecutor, entry: ActivityEntry) {
  for (const data of [entry.before, entry.after]) {
    if (data && Object.keys(data).some(key => !safeKeys.has(key))) throw new Error('Unsafe activity-log field. Extend the allowlist deliberately.');
  }
  await tx.query(`INSERT INTO divyashilla.activity_logs
    (actor_user_id, action, entity_type, entity_id, before_data, after_data, reason, request_id)
    VALUES ($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,$8)`, [entry.actorId,entry.action,entry.entityType,entry.entityId ?? null,
    entry.before ? JSON.stringify(entry.before) : null,entry.after ? JSON.stringify(entry.after) : null,entry.reason ?? null,entry.requestId ?? null]);
}
