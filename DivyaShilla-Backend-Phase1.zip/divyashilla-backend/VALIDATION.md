# Phase 1 validation

Validated on 1 October 2026 with Node.js 24.19.0.

- `npm run typecheck`: passed for source, CLI scripts and tests.
- `npm run build`: passed; backend compiles to JavaScript.
- `npm test`: 18 tests passed, none failed or skipped.
- Database used for automated integration checks: embedded PostgreSQL 18.3 through PGlite 0.5.8, with pg_trgm enabled. HTTP checks use Supertest against the real Express application.
- Original migrations 001–004 are byte-for-byte identical to the previously generated files.
- Verified migration rerun, stored checksums, rejection of altered applied migrations, and transactional rollback of failed migration SQL/history.
- Verified password salt uniqueness, correct/incorrect verification, safe login data, hashed database session tokens, cookie flags, expiry, logout, live role/deactivation checks, Tanaji ADMIN denial, temporary-password restriction, password-change session rotation/revocation, CSRF/origin rejection, request validation, rate limits, health readiness, secret-free activity data and account provisioning.
- Required-audit failure test confirmed that session insertion and last_login_at update roll back together.
- Local environment initialization created valid unique configuration and refused to overwrite an existing .env. Generated credentials are not included in this package.
- `npm audit --omit=dev`: zero reported runtime dependency vulnerabilities at validation time.

Limits: the PostgreSQL TCP driver connection and Docker Desktop were not exercised here. The executable PostgreSQL-engine tests cover SQL behavior using an injected database adapter. Follow README.md to run PostgreSQL locally, then use `/health/ready` and `npm run auth:check` to verify your actual connection. Multi-process rate limiting, multi-connection race testing, Azure connectivity and deployment are outside Phase 1. No live business database or remote repository was changed.
